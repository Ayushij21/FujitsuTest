﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;

namespace APIAutomationCode
{
    public class DataObject
    {
        public string page { get; set; }
    }
    public class APICalls
    {
        private const string URL = "https://reqres.in/";
        private static string ListUser = "/api/users?page=2";
        private static string CreateUser = "/api/users";
        private static string SingleUserNotfound = "/api/users/23";
        private static string ListResource = "/api/unknown";
        private static string SingleResource = "/api/unknown/2";
        private static string SingleResourceNotfound = "/api/unknown/23";
        private static string UpdateUser = "/api/users/2";  //same for patch
        private static string PostLogin = "/api/login";

        private static string DelayedResponse = "/api/users?delay=3";

        static void Main(string[] args)
        {
            GetUserList();
            PostAUser();
            SingleUserNotFound();
            DelayedResponseCheck();
            PostLoginSucess();
            PostLoginUnSuccess();
            UpdateUserAPI();
            UpdateUserPatchAPI();
            Deleteuser();
        }


        public static void GetUserList()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


            // List data response.
            HttpResponseMessage response = client.GetAsync(ListUser).Result;
            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();
                bool b = content.Result.Contains("Lawson");
                Console.WriteLine(response.StatusCode);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }

            client.Dispose();
        }

        public static void PostAUser()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var contentToPost = new FormUrlEncodedContent(new[]
           {
                new KeyValuePair<string, string>("ayushi", "SQA")
            });

            // List data response.
            HttpResponseMessage response = client.PostAsync(ListUser, contentToPost).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void UpdateUserAPI()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var contentToPost = new FormUrlEncodedContent(new[]
           {
                new KeyValuePair<string, string>("morpheus", "zion resident")
            });

            // List data response.
            HttpResponseMessage response = client.PutAsync(UpdateUser, contentToPost).Result;

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine(response.StatusCode);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void UpdateUserPatchAPI()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var contentToPost = new FormUrlEncodedContent(new[]
           {
                new KeyValuePair<string, string>("morpheus","")
            });

            // List data response.
            HttpResponseMessage response = client.PutAsync(UpdateUser, contentToPost).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();
                Console.WriteLine(response.StatusCode);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void Deleteuser()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage response = client.DeleteAsync(UpdateUser).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();
                Console.WriteLine(response.StatusCode);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void SingleUserNotFound()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


            // List data response.
            HttpResponseMessage response = client.GetAsync(SingleUserNotfound).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();

            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void PostLoginSucess()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.

            var contentToPost = new FormUrlEncodedContent(new[]
           {
                new KeyValuePair<string, string>("eve.holt@reqres.in", "cityslicka")
            });

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage response = client.PostAsync(PostLogin, contentToPost).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void PostLoginUnSuccess()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var contentToPost = new FormUrlEncodedContent(new[]
           {
                new KeyValuePair<string, string>("peter@klaven", "")
            });

            // List data response.
            HttpResponseMessage response = client.PostAsync(PostLogin, contentToPost).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public static void DelayedResponseCheck()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            client.Timeout = TimeSpan.FromMinutes(2);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


            // List data response.
            HttpResponseMessage response = client.GetAsync(DelayedResponse).Result;

            if (response.IsSuccessStatusCode)
            {
                var content = response.Content.ReadAsStringAsync();

            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

    }

}

