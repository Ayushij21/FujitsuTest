﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIAutomationCode
{

    public class UserData
    {
        public int Id { get; set; }
        public string Email { get; set; }
        [JsonProperty(PropertyName = "First_Name")]
        public string FirstName { get; set; }
        [JsonProperty(PropertyName = "Last_Name")]
        public string LastName { get; set; }
        public string Avatar { get; set; }
    }

    public class PagingInformation
    {
        public int Page { get; set; }
        [JsonProperty(PropertyName = "Per_Page")]
        public int PerPage { get; set; }
        public int Total { get; set; }
        [JsonProperty(PropertyName = "Total_Pages")]
        public int TotalPages { get; set; }
    }

    public class Support
    {
        public string Url { get; set; }
        public string Text { get; set; }
    }

    public class UserList : PagingInformation
    {
        public List<UserData> Data { get; set; }
        public Support Support { get; set; }
    }
}
